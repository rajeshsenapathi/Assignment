//
//  File.swift
//  iOSProficiencyExercise
//
//  Created by Senapathi Rajesh on 26/12/19.
//  Copyright © 2019 Senapathi Rajesh. All rights reserved.
//

import Foundation
import UIKit
struct Contact {
    let title:String?
    let description :String?
    let imageHref: String?
}
